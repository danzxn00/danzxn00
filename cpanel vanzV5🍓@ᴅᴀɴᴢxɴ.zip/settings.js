/*
SCRIPT INI DI KEMBANGKAN OLEH VANZTZY
BEBAS RECODE ASALKAN TARO CR GUA
© Vanztzy All Right Reversed 2021 -:- 2024
Kalo ada yang error silahkan hubungi vanztzy
*/

require("./all/module.js")
const ctext = (text, style = 1) => {
  var abc = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var xyz = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  abc.map((v, i) =>
    replacer.push({
      original: v,
      convert: xyz[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};
//========== Setting Owner ==========//
global.owner = "6289636823432" // no owner
global.dbowner = "./all/database/owner.json"
global.dbprem = './all/database/premium.json'
global.namaowner = "𝗗𝗔𝗡𝗭𝗫𝗡" // bebas

//======== Setting Bot & Link ========//
global.namabot = "Danzxn Cpanel" // bebas ubah
global.versionbot = `V5`
global.saluran = "https://whatsapp.com/channel/0029Vb0HzSs5kg76srzMWW1i" // bebas
global.linkgc = 'https://chat.whatsapp.com/CwjKZZCsE54LOxTuavcbvv' // bebas
global.sret = "`" // jangan ubah
global.packname = "danzxn cpanel" // bebas
global.author = "danzxn cpanell" // terserah

//========== Setting Event ==========//
global.autoTyping = true
global.welcome = false
global.autoread = false
global.anticall = false 
global.delaypushkontak = 7500
global.delayjpm = 7500

//========= Setting Url Foto =========//
global.image = "https://i.supa.codes/A2ift" 
global.makasi = "https://i.supa.codes/M43dY" 

//========== Setting Panell Server 1 ==========//
global.egg = "15" // egg
global.loc = "1" // location
global.domain = "https://alwayszakzz-1.zakzz.web.id" // ubah jadi domain mu
global.apikey = "ptla_AcbJJNKUHrHAZMfxuqMSHnq0wkPqzFMCtkP3elM5UmB" // ubah jadi apikey mu
global.capikey = "ptlc_8RvAjBTvikGmuf7zeKxSeW2d0L98XsLHu88xhZ7YhlE" // ubah jadi capikey mu

//========== Setting Panel Server 2 ==========//
global.domain2 = "https://alwayszakzz-1.zakzz.web.id" // ubah jadi domain mu
global.apikey2 = "ptla_AcbJJNKUHrHAZMfxuqMSHnq0wkPqzFMCtkP3elM5UmB" // ubah jadi apikey mu
global.capikey2 = "ptlc_8RvAjBTvikGmuf7zeKxSeW2d0L98XsLHu88xhZ7YhlE" // ubah jadi capikey mu

//========= Setting Payment =========//
global.dana = "0895417637940"
global.gopay = "0" // ubah jadi no gopay mu 
global.ovo = "0" // ubah jadi no ovo mu 
global.shopeepay = "0" // ubah jdi no spy mu
global.qris = "https://img86.pixhost.to/images/610/565048535_rizzhosting.jpg" // ubah jadi link Qris mu
global.bri = "0" // ubah jadi no bank mu "2937xxxxxx"
global.atasnama = "danzxn store" // atas nama pay mu
global.syarat1 = "𝗦𝗦 𝗕𝗨𝗞𝗧𝗜 TF‼️" // bebas ubah
global.syarat2 = "𝗔𝗟𝗟 𝗧𝗥𝗫 𝗡𝗢 𝗥𝗘𝗙‼️" // bebas ubah

//========= Jangan Di Ubah =========//
global.rulvip = `*𝗥𝗨𝗟𝗘𝗦 𝗣𝗘𝗠𝗕𝗘𝗟𝗜𝗔𝗡 𝗣𝗔𝗡𝗘𝗟 𝗕𝗬 𝗗𝗔𝗡𝗭𝗫𝗡 𝗦𝗧𝗢𝗥𝗘  ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 1 Detik
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian`
global.pzm = "A"
global.kbh = "B"
global.obp = "C"
global.mkq = "D"
global.epo = "E"
global.hjr = "F"
global.mdm = "G"
global.knt = "H"
global.jmb = "I"
global.sci = "J"
global.dby = "K"
global.zhr = "L"
global.jup = "M"
global.mel = "N"
global.nic = "O"
global.vpd = "P"
global.zqq = "Q"
global.kbs = "R"
global.pxd = "S"
global.ytm = "T"
global.ytv = "U"
global.hdh = "V"
global.wkw = "W"
global.jir = "X"
global.lah = "Y"
global.kok = "Z"
global.pza = "a"
global.kbb = "b"
global.obc = "c"
global.mkd = "d"
global.epe = "e"
global.hjf = "f"
global.mdg = "g"
global.knh = "h"
global.jmi = "i"
global.scj = "j"
global.dbk = "k"
global.zhl = "l"
global.jum = "m"
global.men = "n"
global.nio = "o"
global.vpp = "p"
global.zqp = "q"
global.kbr = "r"
global.pxs = "s"
global.ytt = "t"
global.ytu = "u"
global.hdv = "v"
global.wkm = "w"
global.jix = "x"
global.lay = "y"
global.koz = "z"
global.idsal = "120363341601187231@newsletter"
global.msg = {
"error": "𝗲𝗿𝗿𝗼𝗿 𝗯𝗮𝗻𝗴𝘀𝗮𝘁,𝗰𝗼𝗯𝗮 𝗹𝗮𝗴𝗶😈",
"done": "𝗱𝗮𝘁𝗮 𝘂𝗱𝗮𝗵 𝗱𝗶 𝗮𝗺𝗯𝗶𝗹 ni✅", 
"wait": "𝗗𝗔𝗡𝗭𝗫𝗡 𝗼𝘁𝘄 𝗽𝗿𝗼𝘀𝗲𝘀✅", 
"group": "𝗳𝗶𝘁𝘂𝗿 𝗶𝗻𝗶 𝗸𝗵𝘂𝘀𝘂𝘀 𝗱𝗶 𝗴𝗿𝘂𝗽 𝗻𝗴𝗲𝗻𝘁𝗼𝗱 𝗶𝗱𝗶𝗼𝘁 𝗯𝗮𝗻𝗴𝗲𝘁 𝘀𝗶😴", 
"private": "𝗸𝗵𝘂𝘀𝘂𝘀 𝗱𝗶 𝗰𝗵𝗮𝘁 𝗽𝗿𝗶𝗯 𝗯𝗴 𝗗𝗔𝗡𝗭𝗫𝗡 wa.me/6289636823432", 
"admin": "𝘀𝗼𝗸 𝗮𝘀𝗶𝗸 𝗹𝘂 𝗮𝗷𝗮 𝗯𝘂𝗸𝗮𝗻 𝗮𝗱𝗺𝗶𝗻😹", 
"adminbot": "𝗴𝘄 𝗯𝘂𝗸𝗮𝗻 𝗮𝗱𝗺𝗶𝗷 𝗮𝘀𝘂😑", 
"owner": "𝗹𝘂 𝗯𝘂𝗸𝗮𝗻 𝗯𝗴 𝗗𝗔𝗡𝗭𝗫𝗡,𝗷𝗮𝗱𝗶 𝗴𝗮𝘂𝘀𝗮𝗵 𝗽𝗮𝗸𝗲 𝗳𝗶𝘁𝘂𝗿 ini🤍", 
"developer": "𝗸𝗵𝘂𝘀𝘂𝘀 𝗗𝗔𝗡𝗭𝗫𝗡 𝗱𝗲𝘃🤍"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})